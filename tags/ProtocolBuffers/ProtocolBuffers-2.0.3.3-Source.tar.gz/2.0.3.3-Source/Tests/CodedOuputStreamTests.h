//
//  CodedOuputStreamTests.h
//  ProtocolBuffers
//
//  Created by Cyrus Najmabadi on 10/11/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CodedOutputStreamTests : SenTestCase {

}

@end
