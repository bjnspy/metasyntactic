// Copyright 2008 Cyrus Najmabadi
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import "ProtocolBuffers.h"

#import "Descriptor.pb.h"

@class ObjectiveCFileOptions;
@class ObjectiveCFileOptions_Builder;
@class PBDescriptorProto;
@class PBDescriptorProto_Builder;
@class PBDescriptorProto_ExtensionRange;
@class PBDescriptorProto_ExtensionRange_Builder;
@class PBEnumDescriptorProto;
@class PBEnumDescriptorProto_Builder;
@class PBEnumOptions;
@class PBEnumOptions_Builder;
@class PBEnumValueDescriptorProto;
@class PBEnumValueDescriptorProto_Builder;
@class PBEnumValueOptions;
@class PBEnumValueOptions_Builder;
@class PBFieldDescriptorProto;
@class PBFieldDescriptorProto_Builder;
@class PBFieldOptions;
@class PBFieldOptions_Builder;
@class PBFileDescriptorProto;
@class PBFileDescriptorProto_Builder;
@class PBFileDescriptorSet;
@class PBFileDescriptorSet_Builder;
@class PBFileOptions;
@class PBFileOptions_Builder;
@class PBMessageOptions;
@class PBMessageOptions_Builder;
@class PBMethodDescriptorProto;
@class PBMethodDescriptorProto_Builder;
@class PBMethodOptions;
@class PBMethodOptions_Builder;
@class PBServiceDescriptorProto;
@class PBServiceDescriptorProto_Builder;
@class PBServiceOptions;
@class PBServiceOptions_Builder;
@class PBUninterpretedOption;
@class PBUninterpretedOption_Builder;
@class PBUninterpretedOption_NamePart;
@class PBUninterpretedOption_NamePart_Builder;

@interface ObjectivecDescriptorRoot : NSObject {
}
+ (PBExtensionRegistry*) extensionRegistry;
+ (void) registerAllExtensions:(PBMutableExtensionRegistry*) registry;
+ (id<PBExtensionField>) objectivecFileOptions;
@end

@interface ObjectiveCFileOptions : PBGeneratedMessage {
@private
  BOOL hasObjectivecPackage_:1;
  BOOL hasObjectivecClassPrefix_:1;
  NSString* objectivecPackage;
  NSString* objectivecClassPrefix;
}
- (BOOL) hasObjectivecPackage;
- (BOOL) hasObjectivecClassPrefix;
@property (readonly, retain) NSString* objectivecPackage;
@property (readonly, retain) NSString* objectivecClassPrefix;

+ (ObjectiveCFileOptions*) defaultInstance;
- (ObjectiveCFileOptions*) defaultInstance;

- (BOOL) isInitialized;
- (void) writeToCodedOutputStream:(PBCodedOutputStream*) output;
- (ObjectiveCFileOptions_Builder*) builder;
+ (ObjectiveCFileOptions_Builder*) builder;
+ (ObjectiveCFileOptions_Builder*) builderWithPrototype:(ObjectiveCFileOptions*) prototype;

+ (ObjectiveCFileOptions*) parseFromData:(NSData*) data;
+ (ObjectiveCFileOptions*) parseFromData:(NSData*) data extensionRegistry:(PBExtensionRegistry*) extensionRegistry;
+ (ObjectiveCFileOptions*) parseFromInputStream:(NSInputStream*) input;
+ (ObjectiveCFileOptions*) parseFromInputStream:(NSInputStream*) input extensionRegistry:(PBExtensionRegistry*) extensionRegistry;
+ (ObjectiveCFileOptions*) parseFromCodedInputStream:(PBCodedInputStream*) input;
+ (ObjectiveCFileOptions*) parseFromCodedInputStream:(PBCodedInputStream*) input extensionRegistry:(PBExtensionRegistry*) extensionRegistry;
@end

@interface ObjectiveCFileOptions_Builder : PBGeneratedMessage_Builder {
@private
  ObjectiveCFileOptions* result;
}

- (ObjectiveCFileOptions*) defaultInstance;

- (ObjectiveCFileOptions_Builder*) clear;
- (ObjectiveCFileOptions_Builder*) clone;

- (ObjectiveCFileOptions*) build;
- (ObjectiveCFileOptions*) buildPartial;

- (ObjectiveCFileOptions_Builder*) mergeFrom:(ObjectiveCFileOptions*) other;
- (ObjectiveCFileOptions_Builder*) mergeFromCodedInputStream:(PBCodedInputStream*) input;
- (ObjectiveCFileOptions_Builder*) mergeFromCodedInputStream:(PBCodedInputStream*) input extensionRegistry:(PBExtensionRegistry*) extensionRegistry;

- (BOOL) hasObjectivecPackage;
- (NSString*) objectivecPackage;
- (ObjectiveCFileOptions_Builder*) setObjectivecPackage:(NSString*) value;
- (ObjectiveCFileOptions_Builder*) clearObjectivecPackage;

- (BOOL) hasObjectivecClassPrefix;
- (NSString*) objectivecClassPrefix;
- (ObjectiveCFileOptions_Builder*) setObjectivecClassPrefix:(NSString*) value;
- (ObjectiveCFileOptions_Builder*) clearObjectivecClassPrefix;
@end
